if mods["pyfusionenergy"] then
  -- Fix bad code in science icons updating
  ---@diagnostic disable-next-line
  ITEM("production-science-pack"):set("icon_size", 32)
end
