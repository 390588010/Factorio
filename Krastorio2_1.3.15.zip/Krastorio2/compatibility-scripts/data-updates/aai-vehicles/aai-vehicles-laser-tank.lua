if mods["aai-vehicles-laser-tank"] and data.raw["car"]["vehicle-laser-tank"] then
  data.raw["car"]["vehicle-laser-tank"].equipment_grid = "kr-tank-grid"
end
