if mods["aai-vehicles-warden"] and data.raw["car"]["vehicle-warden"] then
  data.raw["car"]["vehicle-warden"].equipment_grid = "kr-car-grid"
end
