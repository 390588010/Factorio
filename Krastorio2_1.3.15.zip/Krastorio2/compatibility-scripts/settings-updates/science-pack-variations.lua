require("compatibility-scripts/settings-updates/IndustrialRevolution2-part2")
require("compatibility-scripts/settings-updates/aai-industry")
