if mods["pyrawores"] then
  -- Recipes fixes
  krastorio.recipes.removeIngredient("small-lamp", "glass")
end
