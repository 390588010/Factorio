-- -- -- Setting compatibility scripts for science pack
local compatibility_scripts_su = "compatibility-scripts/settings-updates/"
----------
require(compatibility_scripts_su .. "science-pack-variations")
require(compatibility_scripts_su .. "loaders-snap")
require(compatibility_scripts_su .. "IndustrialRevolution2-part1")
----------
