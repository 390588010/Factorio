data:extend({
  {
    type = "damage-type",
    name = "kr-explosion", --special damage for turrets
  },
})
