-- -- Adding new resources

-- Adding rare metals
require(kr_resources_path .. "rare-metals")
-- Adding mineral water
require(kr_resources_path .. "mineral-water")
-- Adding imersite
require(kr_resources_path .. "imersite")
