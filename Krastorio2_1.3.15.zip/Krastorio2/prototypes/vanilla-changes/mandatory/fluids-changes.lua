if data.raw.fluid["petroleum-gas"] then
  data.raw.fluid["petroleum-gas"].fuel_value = "900KJ"
  data.raw.fluid["petroleum-gas"].emissions_multiplier = 1.25
end
