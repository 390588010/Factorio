require(kr_particles_prototypes_path .. "general-particles")
