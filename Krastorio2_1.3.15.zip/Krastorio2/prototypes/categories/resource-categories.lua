data:extend({
  -- New oil category
  {
    type = "resource-category",
    name = "oil",
  },
  -- Krastorio quarry category
  {
    type = "resource-category",
    name = "kr-quarry",
  },
})
