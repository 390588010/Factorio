data:extend({
  -- Images
  {
    type = "sprite",
    name = "kr-open-gui",
    filename = kr_graphic_mod_path .. "gui/buttons/open-wiki.png",
    width = 128,
    height = 128,
  },
})
